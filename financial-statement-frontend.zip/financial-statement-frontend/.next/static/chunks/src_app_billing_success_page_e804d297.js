(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7779f374._.js",
  "static/chunks/src_97ce228b._.js"
],
    source: "dynamic"
});
