(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6aaa83c7._.js",
  "static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_d575f738.js",
  "static/chunks/node_modules_next_dist_compiled_0f1b9fd4._.js",
  "static/chunks/node_modules_next_dist_client_20b209c9._.js",
  "static/chunks/node_modules_next_dist_445d8acf._.js",
  "static/chunks/node_modules_@swc_helpers_cjs_8e433861._.js"
],
    source: "entry"
});
