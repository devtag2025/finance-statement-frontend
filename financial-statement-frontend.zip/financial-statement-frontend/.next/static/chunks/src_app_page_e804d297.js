(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a1ca38bb._.js",
  "static/chunks/src_5ad7999c._.js"
],
    source: "dynamic"
});
