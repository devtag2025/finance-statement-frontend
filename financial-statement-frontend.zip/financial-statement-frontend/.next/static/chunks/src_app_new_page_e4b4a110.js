(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c95f296c._.js",
  "static/chunks/src_07c5d91a._.js"
],
    source: "dynamic"
});
