(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_71f91f34._.js",
  "static/chunks/node_modules_efec2e0f._.js"
],
    source: "dynamic"
});
