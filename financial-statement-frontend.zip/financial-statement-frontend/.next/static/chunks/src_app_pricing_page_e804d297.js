(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_388766ca._.js",
  "static/chunks/src_1f1816c1._.js"
],
    source: "dynamic"
});
