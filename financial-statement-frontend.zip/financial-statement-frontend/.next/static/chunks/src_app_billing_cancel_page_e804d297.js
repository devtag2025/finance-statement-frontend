(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_169301dc._.js",
  "static/chunks/src_edd40cf5._.js"
],
    source: "dynamic"
});
