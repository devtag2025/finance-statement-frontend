(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_abd4d230._.js",
  "static/chunks/src_52c961d8._.js"
],
    source: "dynamic"
});
