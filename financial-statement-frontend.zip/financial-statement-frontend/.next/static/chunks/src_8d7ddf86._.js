(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/service/api.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// service/api.js
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__,
    "getToken": ()=>getToken
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
const axiosInstance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: ("TURBOPACK compile-time value", "http://localhost:3000/api/v1") || "http://localhost:3000/api/v1",
    withCredentials: true
});
const REFRESH_ENDPOINT = "/auth/refresh-token";
// Attach Bearer from localStorage (client only)
axiosInstance.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem("token");
        if (token) {
            config.headers = config.headers || {};
            config.headers.Authorization = "Bearer ".concat(token);
        }
    }
    return config;
}, (error)=>Promise.reject(error));
// ---- Refresh queue to prevent stampede ----
let isRefreshing = false;
let queue = []; // { resolve, reject, original }
// Response interceptor with refresh flow
axiosInstance.interceptors.response.use((res)=>res, async (error)=>{
    var _error_response;
    const original = error.config || {};
    // If the refresh call itself failed, don't recurse—bail out.
    if (original.url && original.url.includes(REFRESH_ENDPOINT)) {
        return Promise.reject(error);
    }
    const status = (_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status;
    if ((status === 401 || status === 403) && !original._retry) {
        original._retry = true;
        if (!isRefreshing) {
            isRefreshing = true;
            try {
                var _data_data;
                // Use same instance so baseURL + withCredentials apply
                const { data } = await axiosInstance.post(REFRESH_ENDPOINT);
                const newToken = (data === null || data === void 0 ? void 0 : (_data_data = data.data) === null || _data_data === void 0 ? void 0 : _data_data.accessToken) || (data === null || data === void 0 ? void 0 : data.accessToken);
                if (newToken) {
                    localStorage.setItem("token", newToken);
                    axiosInstance.defaults.headers.common.Authorization = "Bearer ".concat(newToken);
                    // Flush success: replay all queued requests
                    queue.forEach((param)=>{
                        let { resolve, original: orig } = param;
                        orig.headers = orig.headers || {};
                        orig.headers.Authorization = "Bearer ".concat(newToken);
                        resolve(axiosInstance(orig));
                    });
                    queue = [];
                } else {
                    // No token returned: reject everyone
                    queue.forEach((param)=>{
                        let { reject } = param;
                        return reject(error);
                    });
                    queue = [];
                    localStorage.removeItem("token");
                    return Promise.reject(error);
                }
            } catch (refreshErr) {
                // Refresh failed: reject everyone and clear token
                queue.forEach((param)=>{
                    let { reject } = param;
                    return reject(refreshErr);
                });
                queue = [];
                localStorage.removeItem("token");
                return Promise.reject(refreshErr);
            } finally{
                isRefreshing = false;
            }
        }
        // While refreshing, queue this request
        return new Promise((resolve, reject)=>{
            queue.push({
                resolve,
                reject,
                original
            });
        });
    }
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = axiosInstance;
const getToken = ()=>{
    if ("TURBOPACK compile-time truthy", 1) return localStorage.getItem("token");
    //TURBOPACK unreachable
    ;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/context/AuthContext.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "AuthProvider": ()=>AuthProvider,
    "useAuth": ()=>useAuth
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const extractPayload = (res)=>{
    var _res_data;
    var _res_data_data, _ref;
    return (_ref = (_res_data_data = res === null || res === void 0 ? void 0 : (_res_data = res.data) === null || _res_data === void 0 ? void 0 : _res_data.data) !== null && _res_data_data !== void 0 ? _res_data_data : res === null || res === void 0 ? void 0 : res.data) !== null && _ref !== void 0 ? _ref : {};
};
function AuthProvider(param) {
    let { children } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [accessToken, setAccessToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const setAuthHeader = (token)=>{
        if (token) __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].defaults.headers.common["Authorization"] = "Bearer ".concat(token);
        else delete __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].defaults.headers.common["Authorization"];
    };
    const login = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[login]": async (email, password)=>{
            setLoading(true);
            setError(null);
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/auth/login", {
                    email,
                    password
                });
                const payload = extractPayload(res);
                var _payload_user;
                setUser((_payload_user = payload.user) !== null && _payload_user !== void 0 ? _payload_user : null);
                var _payload_accessToken;
                setAccessToken((_payload_accessToken = payload.accessToken) !== null && _payload_accessToken !== void 0 ? _payload_accessToken : null);
                if (payload.accessToken && "object" !== "undefined") {
                    localStorage.setItem("token", payload.accessToken);
                    setAuthHeader(payload.accessToken);
                }
                return payload;
            } catch (err) {
                var _err_response_data, _err_response;
                var _err_response_data_message;
                const message = (_err_response_data_message = err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) !== null && _err_response_data_message !== void 0 ? _err_response_data_message : "Login failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["AuthProvider.useCallback[login]"], []);
    const register = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[register]": async (formData)=>{
            setLoading(true);
            setError(null);
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/auth/register", formData);
                return extractPayload(res);
            } catch (err) {
                var _err_response_data, _err_response;
                var _err_response_data_message;
                const message = (_err_response_data_message = err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) !== null && _err_response_data_message !== void 0 ? _err_response_data_message : "Registration failed";
                setError(message);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["AuthProvider.useCallback[register]"], []);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[logout]": async ()=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/auth/logout", {}, {
                    withCredentials: true
                });
            } finally{
                setUser(null);
                setAccessToken(null);
                setAuthHeader(null);
                router.push("/login");
                if ("TURBOPACK compile-time truthy", 1) localStorage.removeItem("token");
            }
        }
    }["AuthProvider.useCallback[logout]"], []);
    const fetchProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[fetchProfile]": async ()=>{
            setLoading(true);
            setError(null);
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/auth/profile", {
                    withCredentials: true
                });
                const payload = extractPayload(res);
                var _payload_user;
                setUser((_payload_user = payload.user) !== null && _payload_user !== void 0 ? _payload_user : null);
            } catch (err) {
                var _err_response_data, _err_response;
                setUser(null);
                var _err_response_data_message;
                const message = (_err_response_data_message = err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) !== null && _err_response_data_message !== void 0 ? _err_response_data_message : "Failed to fetch profile";
                setError(message);
            } finally{
                setLoading(false);
            }
        }
    }["AuthProvider.useCallback[fetchProfile]"], []);
    const refreshToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[refreshToken]": async ()=>{
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/auth/refresh-token", {}, {
                    withCredentials: true
                });
                const payload = extractPayload(res);
                if (payload === null || payload === void 0 ? void 0 : payload.accessToken) {
                    setAccessToken(payload.accessToken);
                    setAuthHeader(payload.accessToken);
                    if ("TURBOPACK compile-time truthy", 1) {
                        localStorage.setItem("token", payload.accessToken);
                    }
                }
                return payload;
            } catch (err) {
                setUser(null);
                setAccessToken(null);
                setAuthHeader(null);
                throw err;
            }
        }
    }["AuthProvider.useCallback[refreshToken]"], []);
    // 🔹 NEW: verifyEmail — calls your backend to verify token
    const verifyEmail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[verifyEmail]": async (token)=>{
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/auth/verify-email", {
                params: {
                    token
                }
            });
            const payload = extractPayload(res);
            // normalize shape so your page can do `if (response.success)`
            return {
                success: true,
                data: payload
            };
        }
    }["AuthProvider.useCallback[verifyEmail]"], []);
    // 🔹 NEW: verifyEmailSuccess — central place to update state after success
    const verifyEmailSuccess = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[verifyEmailSuccess]": (userData, accessTok, refreshTok)=>{
            if (userData) setUser(userData);
            if (accessTok) {
                setAccessToken(accessTok);
                setAuthHeader(accessTok);
                if ("TURBOPACK compile-time truthy", 1) localStorage.setItem("token", accessTok);
            }
        // If you also store refreshToken in cookies on the server, nothing else needed here.
        // If you want to keep it client-side (not recommended), you could store it, too.
        }
    }["AuthProvider.useCallback[verifyEmailSuccess]"], []);
    // 🔹 NEW: resendVerificationEmail — to request a new email
    const resendVerificationEmail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[resendVerificationEmail]": async (email)=>{
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/auth/resend-verification", {
                email
            });
            return extractPayload(res); // { success?, message? }
        }
    }["AuthProvider.useCallback[resendVerificationEmail]"], []);
    // (Optional) keep a checkAuth that your UI/page can call
    const checkAuth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[checkAuth]": async ()=>{
            await fetchProfile();
        }
    }["AuthProvider.useCallback[checkAuth]"], [
        fetchProfile
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const token = localStorage.getItem("token");
                if (token) {
                    setAccessToken(token);
                    setAuthHeader(token);
                }
            }
            fetchProfile();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["AuthProvider.useEffect"], []);
    const value = {
        user,
        accessToken,
        loading,
        error,
        isAuthenticated: !!user,
        // auth actions
        login,
        register,
        logout,
        fetchProfile,
        refreshToken,
        // 🔹 newly exposed email-verification helpers
        verifyEmail,
        verifyEmailSuccess,
        resendVerificationEmail,
        checkAuth
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/AuthContext.js",
        lineNumber: 183,
        columnNumber: 10
    }, this);
}
_s(AuthProvider, "Yp0hiDVBW594FBtrn9hM8b/o6bc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AuthProvider;
const useAuth = ()=>{
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (!ctx) throw new Error("useAuth must be used within AuthProvider");
    return ctx;
};
_s1(useAuth, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/toCreatePayload.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// utils/toCreatePayload.js
__turbopack_context__.s({
    "toCreatePayload": ()=>toCreatePayload
});
const ref = (v)=>{
    var _v__id, _ref, _ref1;
    return typeof v === "string" ? v : (_ref1 = (_ref = (_v__id = v === null || v === void 0 ? void 0 : v._id) !== null && _v__id !== void 0 ? _v__id : v === null || v === void 0 ? void 0 : v.id) !== null && _ref !== void 0 ? _ref : v === null || v === void 0 ? void 0 : v.value) !== null && _ref1 !== void 0 ? _ref1 : null;
};
const toCreatePayload = function() {
    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    return {
        ageGroupId: ref(d.ageGroupId),
        themeId: ref(d.themeId),
        subThemeId: ref(d.subThemeId),
        centralMessageId: ref(d.centralMessageId),
        illustrationStyleId: ref(d.illustrationStyleId),
        fontStyleId: ref(d.fontStyleId),
        hobbies: Array.isArray(d.hobbies) ? d.hobbies : (d.hobbies || "").split(",").map((s)=>s.trim()).filter(Boolean),
        favoriteFood: d.favoriteFood || "",
        specialEvent: d.specialEvent || "",
        creatorName: d.creatorName || "",
        bookForward: d.bookForward || ""
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/context/BookContext.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "BookProvider": ()=>BookProvider,
    "useBook": ()=>useBook
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toCreatePayload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/toCreatePayload.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const BookContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const useBook = ()=>{
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(BookContext);
    if (!context) throw new Error("useBook must be used within a BookProvider");
    return context;
};
_s(useBook, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const BookProvider = (param)=>{
    let { children } = param;
    _s1();
    // ---- single-book (create) state ----
    const initialBookDetails = {
        ageGroupId: null,
        themeId: null,
        subThemeId: null,
        centralMessageId: null,
        illustrationStyleId: null,
        fontStyleId: null,
        hobbies: "",
        favoriteFood: "",
        specialEvent: "",
        creatorName: "",
        bookForward: "",
        dedication: ""
    };
    const [bookDetails, setBookDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialBookDetails);
    const [bookId, setBookId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // ---- public test books (list) state ----
    const [testBooks, setTestBooks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [testPagination, setTestPagination] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        currentPage: 1,
        totalPages: 1,
        totalBooks: 0,
        hasNext: false,
        hasPrev: false
    });
    const [testLoading, setTestLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [testError, setTestError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // ---- public single test book (detail) ----
    const [currentBook, setCurrentBook] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentLoading, setCurrentLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentError, setCurrentError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const isTestBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BookProvider.useMemo[isTestBook]": ()=>{
            return !!(bookId && (bookDetails === null || bookDetails === void 0 ? void 0 : bookDetails._id) === bookId && (bookDetails === null || bookDetails === void 0 ? void 0 : bookDetails.isTest) === true);
        }
    }["BookProvider.useMemo[isTestBook]"], [
        bookId,
        bookDetails
    ]);
    // Optional: Create draft (unauthenticated)
    const createDraft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[createDraft]": async (sessionId)=>{
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/books/draft", {
                sessionId,
                bookDetails
            });
            return res === null || res === void 0 ? void 0 : res.data;
        }
    }["BookProvider.useCallback[createDraft]"], [
        bookDetails
    ]);
    // Final book creation (requires auth)
    const createBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[createBook]": async ()=>{
            try {
                var _res_data_data, _res_data;
                setLoading(true);
                setError("");
                const payload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toCreatePayload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCreatePayload"])(bookDetails);
                // console.log("Creating book with payload:", payload);
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/books/create", payload);
                const created = res === null || res === void 0 ? void 0 : (_res_data = res.data) === null || _res_data === void 0 ? void 0 : (_res_data_data = _res_data.data) === null || _res_data_data === void 0 ? void 0 : _res_data_data.book;
                if (created === null || created === void 0 ? void 0 : created._id) setBookId(created._id);
                return created;
            } catch (err) {
                var _err_response_data, _err_response;
                console.error("Book creation failed", err);
                const msg = (err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || "Book creation failed";
                setError(msg);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["BookProvider.useCallback[createBook]"], [
        bookDetails
    ]);
    const clearBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[clearBook]": ()=>{
            setBookDetails(initialBookDetails);
            setBookId(null);
            setError("");
        }
    }["BookProvider.useCallback[clearBook]"], []);
    const setDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[setDetails]": (details)=>{
            setBookDetails({
                "BookProvider.useCallback[setDetails]": (prev)=>({
                        ...prev,
                        ...details
                    })
            }["BookProvider.useCallback[setDetails]"]);
        }
    }["BookProvider.useCallback[setDetails]"], []);
    const resetBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[resetBook]": ()=>{
            setBookId(null);
            setBookDetails(null);
        }
    }["BookProvider.useCallback[resetBook]"], []);
    // ---- fetch public test books (no auth) with dedupe ----
    const inFlightRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastKeyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])("");
    const fetchTestBooks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[fetchTestBooks]": async function() {
            let opts = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
            const { page = 1, limit = 20, status, search, sortBy = "createdAt", sortOrder = "desc" } = opts;
            const key = JSON.stringify({
                page,
                limit,
                status,
                search,
                sortBy,
                sortOrder
            });
            if (lastKeyRef.current === key) return; // already loaded this query
            if (inFlightRef.current) return inFlightRef.current; // already fetching
            setTestLoading(true);
            setTestError("");
            const p = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/books/test-books", {
                params: {
                    page,
                    limit,
                    status,
                    search,
                    sortBy,
                    sortOrder
                },
                withCredentials: false
            }).then({
                "BookProvider.useCallback[fetchTestBooks].p": (res)=>{
                    var _res_data;
                    const payload = (res === null || res === void 0 ? void 0 : (_res_data = res.data) === null || _res_data === void 0 ? void 0 : _res_data.data) || (res === null || res === void 0 ? void 0 : res.data) || {};
                    setTestBooks(payload.books || []);
                    setTestPagination(payload.pagination || {
                        currentPage: 1,
                        totalPages: 1,
                        totalBooks: 0,
                        hasNext: false,
                        hasPrev: false
                    });
                    lastKeyRef.current = key;
                    return payload;
                }
            }["BookProvider.useCallback[fetchTestBooks].p"]).catch({
                "BookProvider.useCallback[fetchTestBooks].p": (err)=>{
                    var _err_response_data, _err_response;
                    const msg = (err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || (err === null || err === void 0 ? void 0 : err.message) || "Failed to fetch test books";
                    setTestError(msg);
                    throw err;
                }
            }["BookProvider.useCallback[fetchTestBooks].p"]).finally({
                "BookProvider.useCallback[fetchTestBooks].p": ()=>{
                    setTestLoading(false);
                    inFlightRef.current = null;
                }
            }["BookProvider.useCallback[fetchTestBooks].p"]);
            inFlightRef.current = p;
            return p;
        }
    }["BookProvider.useCallback[fetchTestBooks]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookProvider.useEffect": ()=>{
            if (!testLoading && testBooks.length === 0) {
                fetchTestBooks({
                    page: 1,
                    limit: 20,
                    status: "completed"
                }).catch({
                    "BookProvider.useEffect": ()=>{}
                }["BookProvider.useEffect"]);
            }
        }
    }["BookProvider.useEffect"], []);
    // ---- load a single public test book by id (no auth) ----
    const loadPublicBookById = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[loadPublicBookById]": async (id)=>{
            if (!id) return null;
            // 2) hit public detail route (you should expose: GET /books/test-books/:id)
            setCurrentLoading(true);
            setCurrentError("");
            try {
                var _res_data;
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/books/test-books/".concat(id), {
                    withCredentials: false
                });
                const payload = (res === null || res === void 0 ? void 0 : (_res_data = res.data) === null || _res_data === void 0 ? void 0 : _res_data.data) || (res === null || res === void 0 ? void 0 : res.data) || {};
                const bk = payload.book || payload;
                setCurrentBook(bk || null);
                return bk || null;
            } catch (err) {
                var _err_response_data, _err_response;
                const msg = (err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || (err === null || err === void 0 ? void 0 : err.message) || "Failed to load book";
                setCurrentError(msg);
                setCurrentBook(null);
                throw err;
            } finally{
                setCurrentLoading(false);
            }
        }
    }["BookProvider.useCallback[loadPublicBookById]"], [
        testBooks
    ]);
    // ---- rename main character across scenes + regenerate PDF (auth) ----
    const renameMainCharacterAndRegenerate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookProvider.useCallback[renameMainCharacterAndRegenerate]": async (param)=>{
            let { bookId: id, fromName, toName, updateTitle = true, persist = true } = param;
            if (!id || !fromName || !toName) {
                throw new Error("bookId, fromName and toName are required");
            }
            try {
                var _res_data;
                setLoading(true);
                setError("");
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/books/".concat(id, "/rename-main-character"), {
                    fromName,
                    toName,
                    updateTitle,
                    persist
                }, {
                    withCredentials: true
                });
                const payload = (res === null || res === void 0 ? void 0 : (_res_data = res.data) === null || _res_data === void 0 ? void 0 : _res_data.data) || (res === null || res === void 0 ? void 0 : res.data) || {};
                // If the currentBook is the same, update it locally
                setCurrentBook({
                    "BookProvider.useCallback[renameMainCharacterAndRegenerate]": (prev)=>{
                        var _payload_book;
                        return prev && (prev._id === id || prev.id === id) ? {
                            ...prev,
                            ...payload.book || {},
                            pdfUrl: payload.pdfUrl || ((_payload_book = payload.book) === null || _payload_book === void 0 ? void 0 : _payload_book.pdfUrl) || prev.pdfUrl
                        } : prev;
                    }
                }["BookProvider.useCallback[renameMainCharacterAndRegenerate]"]);
                return payload;
            } catch (err) {
                var _err_response_data, _err_response;
                const msg = (err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || (err === null || err === void 0 ? void 0 : err.message) || "Failed to rename character";
                setError(msg);
                throw err;
            } finally{
                setLoading(false);
            }
        }
    }["BookProvider.useCallback[renameMainCharacterAndRegenerate]"], []);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BookProvider.useMemo[value]": ()=>({
                // single book flow
                bookDetails,
                setBookDetails,
                setDetails,
                createDraft,
                createBook,
                clearBook,
                bookId,
                setBookId,
                loading,
                error,
                // public list
                fetchTestBooks,
                testBooks,
                testPagination,
                testLoading,
                testError,
                // public single book view
                currentBook,
                setCurrentBook,
                currentLoading,
                currentError,
                loadPublicBookById,
                resetBook,
                // tools
                renameMainCharacterAndRegenerate
            })
    }["BookProvider.useMemo[value]"], [
        bookDetails,
        createDraft,
        createBook,
        clearBook,
        bookId,
        loading,
        error,
        fetchTestBooks,
        testBooks,
        testPagination,
        testLoading,
        testError,
        currentBook,
        currentLoading,
        currentError,
        loadPublicBookById,
        renameMainCharacterAndRegenerate
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BookContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/BookContext.js",
        lineNumber: 319,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(BookProvider, "aH/5V6PMba6AZWFK+3TK9dLraSQ=");
_c = BookProvider;
var _c;
__turbopack_context__.k.register(_c, "BookProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/context/CharacterContext.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// context/CharacterContext.js
__turbopack_context__.s({
    "CharacterProvider": ()=>CharacterProvider,
    "useCharacter": ()=>useCharacter
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
// axios instance with token header
const CharacterContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const useCharacter = ()=>{
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CharacterContext);
    if (!context) {
        throw new Error("useCharacter must be used within a CharacterProvider");
    }
    return context;
};
_s(useCharacter, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const CharacterProvider = (param)=>{
    let { children } = param;
    _s1();
    const [characters, setCharacters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mainCharacter, setMainCharacter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        characterType: "human",
        name: "",
        gender: "",
        age: "",
        picture: null
    });
    const fetchCharacters = async (bookId)=>{
        try {
            setLoading(true);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/characters/book/".concat(bookId));
            setCharacters(res.data.data || []);
        } catch (err) {
            console.error("Failed to fetch characters:", err);
        } finally{
            setLoading(false);
        }
    };
    const uploadCharacter = async (formData)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/characters/upload", formData, {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            });
            return res.data;
        } catch (err) {
            console.error("Upload failed:", err);
            throw err;
        }
    };
    const updateCharacter = async (characterId, updates)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put("/characters/".concat(characterId), updates);
            return res.data;
        } catch (err) {
            console.error("Update failed:", err);
            throw err;
        }
    };
    const deleteCharacter = async (characterId)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete("/characters/".concat(characterId));
            setCharacters((prev)=>prev.filter((c)=>c._id !== characterId));
        } catch (err) {
            console.error("Delete failed:", err);
        }
    };
    const processImage = async (characterId)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/characters/".concat(characterId, "/process"));
            return res.data;
        } catch (err) {
            console.error("Image processing failed:", err);
            throw err;
        }
    };
    const value = {
        characters,
        loading,
        fetchCharacters,
        uploadCharacter,
        updateCharacter,
        deleteCharacter,
        processImage,
        mainCharacter,
        setMainCharacter,
        setCharacters
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CharacterContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/CharacterContext.js",
        lineNumber: 97,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(CharacterProvider, "qiVUxttT0UKgrq5CzagWldbOeWg=");
_c = CharacterProvider;
var _c;
__turbopack_context__.k.register(_c, "CharacterProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/context/ConfigContext.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// context/ConfigContext.js
__turbopack_context__.s({
    "ConfigProvider": ()=>ConfigProvider,
    "useConfig": ()=>useConfig
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const ConfigContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const extractPayload = (res)=>{
    var _res_data;
    return (res === null || res === void 0 ? void 0 : (_res_data = res.data) === null || _res_data === void 0 ? void 0 : _res_data.data) || (res === null || res === void 0 ? void 0 : res.data) || {};
};
const ConfigProvider = (param)=>{
    let { children } = param;
    _s();
    const [config, setConfig] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchAllConfigurations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ConfigProvider.useCallback[fetchAllConfigurations]": async ()=>{
            setLoading(true);
            setError(null);
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/config/all");
                const payload = extractPayload(res);
                setConfig(payload);
            } catch (err) {
                setError((err === null || err === void 0 ? void 0 : err.message) || "Failed to fetch configuration");
            } finally{
                setLoading(false);
            }
        }
    }["ConfigProvider.useCallback[fetchAllConfigurations]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConfigContext.Provider, {
        value: {
            config,
            loading,
            error,
            fetchAllConfigurations
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/ConfigContext.js",
        lineNumber: 31,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ConfigProvider, "fgepNejoqAF9lHYc5EjHCyHzkUk=");
_c = ConfigProvider;
const useConfig = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ConfigContext);
};
_s1(useConfig, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "ConfigProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/context/PaymentContext.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "PaymentProvider": ()=>PaymentProvider,
    "usePayment": ()=>usePayment
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$BookContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/BookContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const PaymentContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const usePayment = ()=>{
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(PaymentContext);
    if (!context) {
        throw new Error("usePayment must be used within a PaymentProvider");
    }
    return context;
};
_s(usePayment, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const PaymentProvider = (param)=>{
    let { children } = param;
    _s1();
    const { bookId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$BookContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBook"])();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        bookId: "",
        billingName: "",
        billingEmail: "",
        paymentIntentId: "",
        clientSecret: "",
        pricing: {
            totalAmount: 0,
            currency: "usd"
        }
    });
    const setDetails = (details)=>{
        setData((prev)=>({
                ...prev,
                ...details
            }));
    };
    const clear = ()=>{
        setData({
            bookId: "",
            billingName: "",
            billingEmail: "",
            paymentIntentId: "",
            clientSecret: "",
            pricing: {
                totalAmount: 0,
                currency: "usd"
            }
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PaymentProvider.useEffect": ()=>{
            if (bookId) {
                setDetails({
                    bookId
                });
            }
        }
    }["PaymentProvider.useEffect"], [
        bookId
    ]);
    const createPaymentIntent = async (billingInfo)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/payments/create-intent", {
                bookId: data.bookId,
                ...billingInfo
            });
            const intent = res.data.data.paymentIntent;
            const pricing = res.data.data.pricing;
            setDetails((prev)=>({
                    ...prev,
                    paymentIntentId: intent.paymentIntentId,
                    clientSecret: intent.clientSecret,
                    pricing,
                    billingName: billingInfo.billingName,
                    billingEmail: billingInfo.billingEmail
                }));
            return {
                success: true,
                intent,
                pricing
            };
        } catch (err) {
            var _err_response_data, _err_response;
            console.error("Failed to create payment intent", err);
            return {
                success: false,
                error: ((_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || err.message
            };
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PaymentContext.Provider, {
        value: {
            data,
            setDetails,
            clear,
            createPaymentIntent
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/PaymentContext.js",
        lineNumber: 88,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(PaymentProvider, "RoPzjH8NYILj9hNU5ZmFHxQGkiE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$BookContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBook"]
    ];
});
_c = PaymentProvider;
var _c;
__turbopack_context__.k.register(_c, "PaymentProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_8d7ddf86._.js.map