(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_9db30cee._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_next_146adb41._.js",
  "static/chunks/node_modules_motion-dom_dist_es_ed5d7820._.js",
  "static/chunks/node_modules_framer-motion_dist_es_906fdbc6._.js",
  "static/chunks/node_modules_05b60e70._.js"
],
    source: "dynamic"
});
