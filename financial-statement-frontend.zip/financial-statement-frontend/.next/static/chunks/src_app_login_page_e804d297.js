(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_168630fe._.js",
  "static/chunks/src_52c961d8._.js"
],
    source: "dynamic"
});
