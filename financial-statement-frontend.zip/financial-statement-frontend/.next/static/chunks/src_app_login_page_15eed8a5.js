(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_64a2b707._.js",
  "static/chunks/src_f2c2afff._.js"
],
    source: "dynamic"
});
