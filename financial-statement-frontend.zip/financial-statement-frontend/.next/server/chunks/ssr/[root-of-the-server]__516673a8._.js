module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/path [external] (path, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/assert [external] (assert, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}}),
"[externals]/tty [external] (tty, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}}),
"[externals]/os [external] (os, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[project]/src/service/api.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// service/api.js
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__,
    "getToken": ()=>getToken
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
;
const axiosInstance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: ("TURBOPACK compile-time value", "http://localhost:3000/api/v1") || "http://localhost:3000/api/v1",
    withCredentials: true
});
const REFRESH_ENDPOINT = "/auth/refresh-token";
// Attach Bearer from localStorage (client only)
axiosInstance.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return config;
}, (error)=>Promise.reject(error));
// ---- Refresh queue to prevent stampede ----
let isRefreshing = false;
let queue = []; // { resolve, reject, original }
// Response interceptor with refresh flow
axiosInstance.interceptors.response.use((res)=>res, async (error)=>{
    const original = error.config || {};
    // If the refresh call itself failed, don't recurse—bail out.
    if (original.url && original.url.includes(REFRESH_ENDPOINT)) {
        return Promise.reject(error);
    }
    const status = error.response?.status;
    if ((status === 401 || status === 403) && !original._retry) {
        original._retry = true;
        if (!isRefreshing) {
            isRefreshing = true;
            try {
                // Use same instance so baseURL + withCredentials apply
                const { data } = await axiosInstance.post(REFRESH_ENDPOINT);
                const newToken = data?.data?.accessToken || data?.accessToken;
                if (newToken) {
                    localStorage.setItem("token", newToken);
                    axiosInstance.defaults.headers.common.Authorization = `Bearer ${newToken}`;
                    // Flush success: replay all queued requests
                    queue.forEach(({ resolve, original: orig })=>{
                        orig.headers = orig.headers || {};
                        orig.headers.Authorization = `Bearer ${newToken}`;
                        resolve(axiosInstance(orig));
                    });
                    queue = [];
                } else {
                    // No token returned: reject everyone
                    queue.forEach(({ reject })=>reject(error));
                    queue = [];
                    localStorage.removeItem("token");
                    return Promise.reject(error);
                }
            } catch (refreshErr) {
                // Refresh failed: reject everyone and clear token
                queue.forEach(({ reject })=>reject(refreshErr));
                queue = [];
                localStorage.removeItem("token");
                return Promise.reject(refreshErr);
            } finally{
                isRefreshing = false;
            }
        }
        // While refreshing, queue this request
        return new Promise((resolve, reject)=>{
            queue.push({
                resolve,
                reject,
                original
            });
        });
    }
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = axiosInstance;
const getToken = ()=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return null;
};
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/context/AuthContext.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "AuthProvider": ()=>AuthProvider,
    "useAuth": ()=>useAuth
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
const extractPayload = (res)=>res?.data?.data ?? res?.data ?? {};
function AuthProvider({ children }) {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [accessToken, setAccessToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const setAuthHeader = (token)=>{
        if (token) __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].defaults.headers.common["Authorization"] = `Bearer ${token}`;
        else delete __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].defaults.headers.common["Authorization"];
    };
    const login = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (email, password)=>{
        setLoading(true);
        setError(null);
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/auth/login", {
                email,
                password
            });
            const payload = extractPayload(res);
            setUser(payload.user ?? null);
            setAccessToken(payload.accessToken ?? null);
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return payload;
        } catch (err) {
            const message = err?.response?.data?.message ?? "Login failed";
            setError(message);
            throw err;
        } finally{
            setLoading(false);
        }
    }, []);
    const register = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (formData)=>{
        setLoading(true);
        setError(null);
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/auth/register", formData);
            return extractPayload(res);
        } catch (err) {
            const message = err?.response?.data?.message ?? "Registration failed";
            setError(message);
            throw err;
        } finally{
            setLoading(false);
        }
    }, []);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/auth/logout", {}, {
                withCredentials: true
            });
        } finally{
            setUser(null);
            setAccessToken(null);
            setAuthHeader(null);
            router.push("/login");
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }
    }, []);
    const fetchProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        setLoading(true);
        setError(null);
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/auth/profile", {
                withCredentials: true
            });
            const payload = extractPayload(res);
            setUser(payload.user ?? null);
        } catch (err) {
            setUser(null);
            const message = err?.response?.data?.message ?? "Failed to fetch profile";
            setError(message);
        } finally{
            setLoading(false);
        }
    }, []);
    const refreshToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/auth/refresh-token", {}, {
                withCredentials: true
            });
            const payload = extractPayload(res);
            if (payload?.accessToken) {
                setAccessToken(payload.accessToken);
                setAuthHeader(payload.accessToken);
                if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                ;
            }
            return payload;
        } catch (err) {
            setUser(null);
            setAccessToken(null);
            setAuthHeader(null);
            throw err;
        }
    }, []);
    // 🔹 NEW: verifyEmail — calls your backend to verify token
    const verifyEmail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (token)=>{
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/auth/verify-email", {
            params: {
                token
            }
        });
        const payload = extractPayload(res);
        // normalize shape so your page can do `if (response.success)`
        return {
            success: true,
            data: payload
        };
    }, []);
    // 🔹 NEW: verifyEmailSuccess — central place to update state after success
    const verifyEmailSuccess = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((userData, accessTok, refreshTok)=>{
        if (userData) setUser(userData);
        if (accessTok) {
            setAccessToken(accessTok);
            setAuthHeader(accessTok);
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }
    // If you also store refreshToken in cookies on the server, nothing else needed here.
    // If you want to keep it client-side (not recommended), you could store it, too.
    }, []);
    // 🔹 NEW: resendVerificationEmail — to request a new email
    const resendVerificationEmail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (email)=>{
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/auth/resend-verification", {
            email
        });
        return extractPayload(res); // { success?, message? }
    }, []);
    // (Optional) keep a checkAuth that your UI/page can call
    const checkAuth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        await fetchProfile();
    }, [
        fetchProfile
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        fetchProfile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const value = {
        user,
        accessToken,
        loading,
        error,
        isAuthenticated: !!user,
        // auth actions
        login,
        register,
        logout,
        fetchProfile,
        refreshToken,
        // 🔹 newly exposed email-verification helpers
        verifyEmail,
        verifyEmailSuccess,
        resendVerificationEmail,
        checkAuth
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/AuthContext.js",
        lineNumber: 183,
        columnNumber: 10
    }, this);
}
const useAuth = ()=>{
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (!ctx) throw new Error("useAuth must be used within AuthProvider");
    return ctx;
};
}),
"[project]/src/utils/toCreatePayload.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// utils/toCreatePayload.js
__turbopack_context__.s({
    "toCreatePayload": ()=>toCreatePayload
});
const ref = (v)=>typeof v === "string" ? v : v?._id ?? v?.id ?? v?.value ?? null;
const toCreatePayload = (d = {})=>({
        ageGroupId: ref(d.ageGroupId),
        themeId: ref(d.themeId),
        subThemeId: ref(d.subThemeId),
        centralMessageId: ref(d.centralMessageId),
        illustrationStyleId: ref(d.illustrationStyleId),
        fontStyleId: ref(d.fontStyleId),
        hobbies: Array.isArray(d.hobbies) ? d.hobbies : (d.hobbies || "").split(",").map((s)=>s.trim()).filter(Boolean),
        favoriteFood: d.favoriteFood || "",
        specialEvent: d.specialEvent || "",
        creatorName: d.creatorName || "",
        bookForward: d.bookForward || ""
    });
}),
"[project]/src/context/BookContext.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "BookProvider": ()=>BookProvider,
    "useBook": ()=>useBook
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toCreatePayload$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/toCreatePayload.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const BookContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
const useBook = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(BookContext);
    if (!context) throw new Error("useBook must be used within a BookProvider");
    return context;
};
const BookProvider = ({ children })=>{
    // ---- single-book (create) state ----
    const initialBookDetails = {
        ageGroupId: null,
        themeId: null,
        subThemeId: null,
        centralMessageId: null,
        illustrationStyleId: null,
        fontStyleId: null,
        hobbies: "",
        favoriteFood: "",
        specialEvent: "",
        creatorName: "",
        bookForward: "",
        dedication: ""
    };
    const [bookDetails, setBookDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialBookDetails);
    const [bookId, setBookId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    // ---- public test books (list) state ----
    const [testBooks, setTestBooks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [testPagination, setTestPagination] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        currentPage: 1,
        totalPages: 1,
        totalBooks: 0,
        hasNext: false,
        hasPrev: false
    });
    const [testLoading, setTestLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [testError, setTestError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    // ---- public single test book (detail) ----
    const [currentBook, setCurrentBook] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentLoading, setCurrentLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentError, setCurrentError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const isTestBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return !!(bookId && bookDetails?._id === bookId && bookDetails?.isTest === true);
    }, [
        bookId,
        bookDetails
    ]);
    // Optional: Create draft (unauthenticated)
    const createDraft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (sessionId)=>{
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/books/draft", {
            sessionId,
            bookDetails
        });
        return res?.data;
    }, [
        bookDetails
    ]);
    // Final book creation (requires auth)
    const createBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        try {
            setLoading(true);
            setError("");
            const payload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$toCreatePayload$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toCreatePayload"])(bookDetails);
            // console.log("Creating book with payload:", payload);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/books/create", payload);
            const created = res?.data?.data?.book;
            if (created?._id) setBookId(created._id);
            return created;
        } catch (err) {
            console.error("Book creation failed", err);
            const msg = err?.response?.data?.message || "Book creation failed";
            setError(msg);
            throw err;
        } finally{
            setLoading(false);
        }
    }, [
        bookDetails
    ]);
    const clearBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        setBookDetails(initialBookDetails);
        setBookId(null);
        setError("");
    }, []);
    const setDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((details)=>{
        setBookDetails((prev)=>({
                ...prev,
                ...details
            }));
    }, []);
    const resetBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        setBookId(null);
        setBookDetails(null);
    }, []);
    // ---- fetch public test books (no auth) with dedupe ----
    const inFlightRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastKeyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])("");
    const fetchTestBooks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (opts = {})=>{
        const { page = 1, limit = 20, status, search, sortBy = "createdAt", sortOrder = "desc" } = opts;
        const key = JSON.stringify({
            page,
            limit,
            status,
            search,
            sortBy,
            sortOrder
        });
        if (lastKeyRef.current === key) return; // already loaded this query
        if (inFlightRef.current) return inFlightRef.current; // already fetching
        setTestLoading(true);
        setTestError("");
        const p = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/books/test-books", {
            params: {
                page,
                limit,
                status,
                search,
                sortBy,
                sortOrder
            },
            withCredentials: false
        }).then((res)=>{
            const payload = res?.data?.data || res?.data || {};
            setTestBooks(payload.books || []);
            setTestPagination(payload.pagination || {
                currentPage: 1,
                totalPages: 1,
                totalBooks: 0,
                hasNext: false,
                hasPrev: false
            });
            lastKeyRef.current = key;
            return payload;
        }).catch((err)=>{
            const msg = err?.response?.data?.message || err?.message || "Failed to fetch test books";
            setTestError(msg);
            throw err;
        }).finally(()=>{
            setTestLoading(false);
            inFlightRef.current = null;
        });
        inFlightRef.current = p;
        return p;
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!testLoading && testBooks.length === 0) {
            fetchTestBooks({
                page: 1,
                limit: 20,
                status: "completed"
            }).catch(()=>{});
        }
    }, []);
    // ---- load a single public test book by id (no auth) ----
    const loadPublicBookById = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (id)=>{
        if (!id) return null;
        // 2) hit public detail route (you should expose: GET /books/test-books/:id)
        setCurrentLoading(true);
        setCurrentError("");
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/books/test-books/${id}`, {
                withCredentials: false
            });
            const payload = res?.data?.data || res?.data || {};
            const bk = payload.book || payload;
            setCurrentBook(bk || null);
            return bk || null;
        } catch (err) {
            const msg = err?.response?.data?.message || err?.message || "Failed to load book";
            setCurrentError(msg);
            setCurrentBook(null);
            throw err;
        } finally{
            setCurrentLoading(false);
        }
    }, [
        testBooks
    ]);
    // ---- rename main character across scenes + regenerate PDF (auth) ----
    const renameMainCharacterAndRegenerate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ({ bookId: id, fromName, toName, updateTitle = true, persist = true })=>{
        if (!id || !fromName || !toName) {
            throw new Error("bookId, fromName and toName are required");
        }
        try {
            setLoading(true);
            setError("");
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post(`/books/${id}/rename-main-character`, {
                fromName,
                toName,
                updateTitle,
                persist
            }, {
                withCredentials: true
            });
            const payload = res?.data?.data || res?.data || {};
            // If the currentBook is the same, update it locally
            setCurrentBook((prev)=>prev && (prev._id === id || prev.id === id) ? {
                    ...prev,
                    ...payload.book || {},
                    pdfUrl: payload.pdfUrl || payload.book?.pdfUrl || prev.pdfUrl
                } : prev);
            return payload;
        } catch (err) {
            const msg = err?.response?.data?.message || err?.message || "Failed to rename character";
            setError(msg);
            throw err;
        } finally{
            setLoading(false);
        }
    }, []);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            // single book flow
            bookDetails,
            setBookDetails,
            setDetails,
            createDraft,
            createBook,
            clearBook,
            bookId,
            setBookId,
            loading,
            error,
            // public list
            fetchTestBooks,
            testBooks,
            testPagination,
            testLoading,
            testError,
            // public single book view
            currentBook,
            setCurrentBook,
            currentLoading,
            currentError,
            loadPublicBookById,
            resetBook,
            // tools
            renameMainCharacterAndRegenerate
        }), [
        bookDetails,
        createDraft,
        createBook,
        clearBook,
        bookId,
        loading,
        error,
        fetchTestBooks,
        testBooks,
        testPagination,
        testLoading,
        testError,
        currentBook,
        currentLoading,
        currentError,
        loadPublicBookById,
        renameMainCharacterAndRegenerate
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(BookContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/BookContext.js",
        lineNumber: 319,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
}),
"[project]/src/context/CharacterContext.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// context/CharacterContext.js
__turbopack_context__.s({
    "CharacterProvider": ()=>CharacterProvider,
    "useCharacter": ()=>useCharacter
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
// axios instance with token header
const CharacterContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
const useCharacter = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(CharacterContext);
    if (!context) {
        throw new Error("useCharacter must be used within a CharacterProvider");
    }
    return context;
};
const CharacterProvider = ({ children })=>{
    const [characters, setCharacters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mainCharacter, setMainCharacter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        characterType: "human",
        name: "",
        gender: "",
        age: "",
        picture: null
    });
    const fetchCharacters = async (bookId)=>{
        try {
            setLoading(true);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/characters/book/${bookId}`);
            setCharacters(res.data.data || []);
        } catch (err) {
            console.error("Failed to fetch characters:", err);
        } finally{
            setLoading(false);
        }
    };
    const uploadCharacter = async (formData)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/characters/upload", formData, {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            });
            return res.data;
        } catch (err) {
            console.error("Upload failed:", err);
            throw err;
        }
    };
    const updateCharacter = async (characterId, updates)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put(`/characters/${characterId}`, updates);
            return res.data;
        } catch (err) {
            console.error("Update failed:", err);
            throw err;
        }
    };
    const deleteCharacter = async (characterId)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].delete(`/characters/${characterId}`);
            setCharacters((prev)=>prev.filter((c)=>c._id !== characterId));
        } catch (err) {
            console.error("Delete failed:", err);
        }
    };
    const processImage = async (characterId)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post(`/characters/${characterId}/process`);
            return res.data;
        } catch (err) {
            console.error("Image processing failed:", err);
            throw err;
        }
    };
    const value = {
        characters,
        loading,
        fetchCharacters,
        uploadCharacter,
        updateCharacter,
        deleteCharacter,
        processImage,
        mainCharacter,
        setMainCharacter,
        setCharacters
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CharacterContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/CharacterContext.js",
        lineNumber: 97,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
}),
"[project]/src/context/ConfigContext.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// context/ConfigContext.js
__turbopack_context__.s({
    "ConfigProvider": ()=>ConfigProvider,
    "useConfig": ()=>useConfig
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const ConfigContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
const extractPayload = (res)=>res?.data?.data || res?.data || {};
const ConfigProvider = ({ children })=>{
    const [config, setConfig] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchAllConfigurations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        setLoading(true);
        setError(null);
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/config/all");
            const payload = extractPayload(res);
            setConfig(payload);
        } catch (err) {
            setError(err?.message || "Failed to fetch configuration");
        } finally{
            setLoading(false);
        }
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ConfigContext.Provider, {
        value: {
            config,
            loading,
            error,
            fetchAllConfigurations
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/ConfigContext.js",
        lineNumber: 31,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const useConfig = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ConfigContext);
}),
"[project]/src/context/PaymentContext.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "PaymentProvider": ()=>PaymentProvider,
    "usePayment": ()=>usePayment
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$BookContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/BookContext.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/api.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const PaymentContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
const usePayment = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(PaymentContext);
    if (!context) {
        throw new Error("usePayment must be used within a PaymentProvider");
    }
    return context;
};
const PaymentProvider = ({ children })=>{
    const { bookId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$BookContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useBook"])();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        bookId: "",
        billingName: "",
        billingEmail: "",
        paymentIntentId: "",
        clientSecret: "",
        pricing: {
            totalAmount: 0,
            currency: "usd"
        }
    });
    const setDetails = (details)=>{
        setData((prev)=>({
                ...prev,
                ...details
            }));
    };
    const clear = ()=>{
        setData({
            bookId: "",
            billingName: "",
            billingEmail: "",
            paymentIntentId: "",
            clientSecret: "",
            pricing: {
                totalAmount: 0,
                currency: "usd"
            }
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (bookId) {
            setDetails({
                bookId
            });
        }
    }, [
        bookId
    ]);
    const createPaymentIntent = async (billingInfo)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/payments/create-intent", {
                bookId: data.bookId,
                ...billingInfo
            });
            const intent = res.data.data.paymentIntent;
            const pricing = res.data.data.pricing;
            setDetails((prev)=>({
                    ...prev,
                    paymentIntentId: intent.paymentIntentId,
                    clientSecret: intent.clientSecret,
                    pricing,
                    billingName: billingInfo.billingName,
                    billingEmail: billingInfo.billingEmail
                }));
            return {
                success: true,
                intent,
                pricing
            };
        } catch (err) {
            console.error("Failed to create payment intent", err);
            return {
                success: false,
                error: err.response?.data?.message || err.message
            };
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(PaymentContext.Provider, {
        value: {
            data,
            setDetails,
            clear,
            createPaymentIntent
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/PaymentContext.js",
        lineNumber: 88,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__516673a8._.js.map