module.exports = {

"[project]/src/app/icon.jpeg (static in ecmascript)": ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/icon.8c7512fe.jpeg");}),
"[project]/src/app/icon.jpeg.mjs { IMAGE => \"[project]/src/app/icon.jpeg (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$icon$2e$jpeg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/icon.jpeg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$icon$2e$jpeg__$28$static__in__ecmascript$29$__["default"],
    width: 561,
    height: 452
};
}),

};

//# sourceMappingURL=src_app_c6f3ac4e._.js.map