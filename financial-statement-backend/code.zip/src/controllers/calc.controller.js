const { runCalc } = require('../services/calc.service');

exports.calc = async (req, res) => {
  try {
    const { fields, ruleVersion } = req.body;

    if (!Array.isArray(fields)) {
      return res.status(400).json({ ok: false, reasons: ['BAD_REQUEST'] });
    }

    const out = runCalc(fields, ruleVersion);
    if (!out.ok) {
      return res.status(422).json(out);
    }

    // Optionally round values for presentation (keep raw too if you need)
    const rounded = {};
    for (const [k, v] of Object.entries(out.results)) {
      // Keep two decimals for money-like outputs
      rounded[k] = Math.round((v + Number.EPSILON) * 100) / 100;
    }

    return res.json({
      ok: true,
      results: rounded,
      trace: out.trace,
      ruleVersion: ruleVersion || 'v1'
    });
  } catch (e) {
    return res.status(500).json({ ok: false, reasons: ['INTERNAL_ERROR'] });
  }
};
