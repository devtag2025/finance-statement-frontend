const crypto = require('crypto');
const { stripe, createCheckoutSession, createBillingPortal } = require('../services/payments.service');
const Users = require('../models/user.model'); // adjust path

exports.createCheckout = async (req, res) => {
  // auth middleware should set req.user
  const { planKey } = req.body; // 'basic' | 'pro'
  if (!['basic','pro'].includes(planKey)) return res.status(400).json({ ok:false, reason:'BAD_PLAN' });

  const session = await createCheckoutSession({
    user: req.user,
    planKey,
    successUrl: `${process.env.APP_BASE_URL}/billing/success`,
    cancelUrl: `${process.env.APP_BASE_URL}/billing/cancel`,
  });

  res.json({ ok:true, url: session.url });
};

exports.createPortal = async (req, res) => {
  const portal = await createBillingPortal({
    user: req.user,
    returnUrl: `${process.env.APP_BASE_URL}/account`,
  });
  res.json({ ok:true, url: portal.url });
};

// Webhook must receive RAW body (configure app.use as raw for this route)
exports.webhook = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (e) {
    return res.status(400).send(`Webhook Error: ${e.message}`);
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const cs = event.data.object;
        const customerId = cs.customer;
        // find user by stripeCustomerId or client_reference_id
        let user = await Users.findOne({ stripeCustomerId: customerId });
        if (!user && cs.client_reference_id) user = await Users.findById(cs.client_reference_id);
        if (user && !user.stripeCustomerId) {
          user.stripeCustomerId = customerId;
        }
        // The subscription is available on cs.subscription
        if (user && cs.subscription) {
          user.stripeSubscriptionId = cs.subscription;
          user.subscriptionStatus = 'active'; // will be updated in subscription.updated
          await user.save();
        }
        break;
      }
      case 'customer.subscription.updated':
      case 'customer.subscription.created':
      case 'customer.subscription.deleted': {
        const sub = event.data.object;
        const customerId = sub.customer;
        const user = await Users.findOne({ stripeCustomerId: customerId });
        if (user) {
          user.stripeSubscriptionId = sub.id;
          user.subscriptionStatus = sub.status;
          user.currentPeriodEnd = new Date(sub.current_period_end * 1000);
          const price = sub.items?.data?.[0]?.price;
          user.planKey = price?.id === process.env.STRIPE_PRICE_PRO ? 'pro' : 'basic';
          await user.save();
        }
        break;
      }
      default:
        // ignore
        break;
    }
    res.sendStatus(200);
  } catch (e) {
    res.status(500).send('Webhook handler error');
  }
};
