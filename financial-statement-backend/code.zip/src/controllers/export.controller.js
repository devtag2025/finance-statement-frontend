const dayjs = require('dayjs');
const { seen, remember } = require('../utils/idempotency');
const { streamPDF, streamCSV } = require('../services/export.service');

// Expected body:
// {
//   "fields": [{ id, label, value, included, confidence, page }, ...],
//   "results": { "totals.revenue": 123.45, "net_income": 99.99, ... },
//   "format": "pdf" | "csv",
//   "fileName": "optional-base-name",
//   "idempotencyKey": "required to avoid duplicate export"
// }
exports.exportHandler = async (req, res) => {
  try {
    const { fields, results, format, fileName, idempotencyKey } = req.body || {};

    // Basic validation
    if (!Array.isArray(fields) || typeof results !== 'object' || !results) {
      return res.status(400).json({ ok: false, reasons: ['BAD_REQUEST'] });
    }
    if (format !== 'pdf' && format !== 'csv') {
      return res.status(400).json({ ok: false, reasons: ['UNSUPPORTED_FORMAT'] });
    }
    if (!idempotencyKey || typeof idempotencyKey !== 'string') {
      return res.status(400).json({ ok: false, reasons: ['IDEMPOTENCY_KEY_REQUIRED'] });
    }
    if (seen(idempotencyKey)) {
      // Do not re-generate; reply with a 409 or 200 with a hint (choose policy)
      return res.status(409).json({ ok: false, reasons: ['IDEMPOTENT_REPLAY'] });
    }
    remember(idempotencyKey);

    const base = (fileName && String(fileName).replace(/[^\w.-]/g, '')) || 'financial-statement';
    const ts = dayjs().format('YYYYMMDD_HHmmss');

    if (format === 'pdf') {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${base}_${ts}.pdf"`);
      // stream and end inside service
      return streamPDF(res, fields, results, { title: 'Financial Statement Results', timezone: 'UTC' });
    }

    // CSV
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${base}_${ts}.csv"`);
    return streamCSV(res, fields, results);

  } catch (e) {
    // If headers already sent (streaming), you can't send JSON; here we're safe.
    return res.status(500).json({ ok: false, reasons: ['INTERNAL_ERROR'] });
  }
};
