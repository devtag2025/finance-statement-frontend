const { fileTypeFromBuffer } = require('file-type');
const pdfParse = require('pdf-parse');
const {
  MAX_PAGES,
  MAX_SIZE_BYTES,
  ALLOWED_MIME,
  ALLOWED_EXT,
} = require('../config/uploadConfig');

function buildError(res, reasons, extra = {}) {
  return res.status(422).json({
    ok: false,
    checks: { typeOk: false, sizeOk: false, pagesOk: false, ...extra.checks },
    warnings: extra.warnings || [],
    reasons,
    ...extra.meta,
  });
}

exports.validateUpload = async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({
        ok: false,
        checks: { typeOk: false, sizeOk: false, pagesOk: false },
        warnings: [],
        reasons: ['NO_FILE'],
      });
    }

    // Size check (multer enforces, but double-check)
    const sizeOk = file.size <= MAX_SIZE_BYTES;

    // Magic bytes detection (prefer over extension)
    let detectedMime;
    let detectedExt;
    try {
      const ft = await fileTypeFromBuffer(file.buffer);
      if (ft) {
        detectedMime = ft.mime;
        detectedExt = ft.ext;
      } else {
        detectedMime = file.mimetype; // fallback
        const name = (file.originalname || '').toLowerCase();
        detectedExt = name.includes('.') ? name.split('.').pop() : undefined;
      }
    } catch (e) {
      // Leave undefined → will fail typeOk
    }

    const typeOk =
      Boolean(detectedMime) &&
      ALLOWED_MIME.has(detectedMime) &&
      Boolean(detectedExt) &&
      ALLOWED_EXT.has(detectedExt);

    // Page count
    let pages = 1;
    let pagesOk = true;
    const warnings = [];

    try {
      if (detectedMime === 'application/pdf') {
        const parsed = await pdfParse(file.buffer);
        pages = parsed.numpages || 0;
        if (!pages) warnings.push('PDF_PAGE_COUNT_UNCERTAIN');
      } else if (detectedMime === 'image/jpeg' || detectedMime === 'image/png') {
        pages = 1; // images considered single page
      } else {
        // Unknown type → already caught by typeOk, but set pages invalid
        pages = 0;
      }
      pagesOk = pages > 0 && pages <= MAX_PAGES;
    } catch (err) {
      pagesOk = false;
      warnings.push('PAGE_COUNT_FAILED');
    }

    const verdictOk = typeOk && sizeOk && pagesOk;

    const payload = {
      ok: verdictOk,
      mime: detectedMime,
      ext: detectedExt,
      sizeBytes: file.size,
      pages,
      checks: { typeOk, sizeOk, pagesOk },
      warnings,
    };

    if (!verdictOk) {
      const reasons = [];
      if (!typeOk) reasons.push('UNSUPPORTED_TYPE');
      if (!sizeOk) reasons.push('FILE_TOO_LARGE');
      if (!pagesOk) reasons.push('PAGE_LIMIT_EXCEEDED');

      return res.status(422).json({ ...payload, reasons });
    }

    return res.json(payload);
  } catch (err) {
    // System errors (not user input)
    return res.status(500).json({
      ok: false,
      reasons: ['INTERNAL_ERROR'],
    });
  }
};
