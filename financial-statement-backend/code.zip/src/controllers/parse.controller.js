const { toNumber } = require('../utils/num');
const rules = require('../config/parseRules');

function findFirst(regexes, text) {
  for (const r of regexes) {
    const m = text.match(r);
    if (m) return { match: m[0], index: m.index };
  }
  return null;
}

function extractNearNumber(text, startIdx, windowSize, numberPattern) {
  const from = Math.max(0, startIdx);
  const to = Math.min(text.length, startIdx + windowSize);
  const slice = text.slice(from, to);
  const m = slice.match(numberPattern);
  if (!m) return null;
  return { raw: m[0], offset: from + m.index };
}

function extractNearDate(text, startIdx, windowSize, datePattern) {
  const from = Math.max(0, startIdx);
  const to = Math.min(text.length, startIdx + windowSize);
  const slice = text.slice(from, to);
  const m = slice.match(datePattern);
  if (!m) return null;
  return { raw: m[1], offset: from + m.index };
}

function scoreConfidence(raw) {
  // Super light heuristic: longer numeric strings & with decimals get higher confidence
  if (!raw) return 0.4;
  let conf = 0.6;
  if (/[.,]/.test(raw)) conf += 0.1;
  if (/\(/.test(raw)) conf += 0.05;
  if (raw.replace(/\D/g, '').length >= 5) conf += 0.1;
  return Math.min(conf, 0.95);
}

exports.parse = async (req, res) => {
  try {
    const { pages } = req.body; // [{ page: 1, text: "..." }, ...]
    if (!Array.isArray(pages) || pages.length === 0) {
      return res.status(400).json({ ok: false, reasons: ['BAD_REQUEST'] });
    }

    const fields = [];
    const seenKeys = new Set();

    for (const p of pages) {
      const pageNum = p.page || 1;
      const text = String(p.text || '');
      if (!text.trim()) continue;

      // For each anchor we know, try to find a nearby number/date
      for (const anchor of rules.anchors) {
        const hit = findFirst(anchor.labels, text);
        if (!hit) continue;

        let value = null;
        let type = 'text';
        let raw = null;

        // If key implies money/number, try number | else try date then number
        if (/period\./.test(anchor.key)) {
          const d = extractNearDate(text, hit.index, rules.window, rules.datePattern);
          if (d) {
            raw = d.raw;
            value = raw;
            type = 'date';
          }
        }
        if (value == null) {
          const n = extractNearNumber(text, hit.index, rules.window, rules.numberPattern);
          if (n) {
            raw = n.raw;
            const num = toNumber(raw);
            if (num != null) {
              value = num;
              type = 'currency';
            }
          }
        }

        // Build field (even if null value, user can edit later)
        const id = `${anchor.key}@p${pageNum}`;
        const confidence = value == null ? 0.4 : scoreConfidence(raw);
        const field = {
          id,
          label: anchor.key,   // frontend can map pretty labels
          value: value == null ? '' : value,
          type,
          included: true,
          confidence,
          page: pageNum,
        };

        // Avoid duplicates (first hit wins per key)
        if (!seenKeys.has(anchor.key)) {
          fields.push(field);
          seenKeys.add(anchor.key);
        }
      }
    }

    // Fallback: if nothing parsed, return a hint field so UI can prompt manual entry
    if (fields.length === 0) {
      fields.push({
        id: 'hint.manual',
        label: 'hint.manual',
        value: '',
        type: 'text',
        included: true,
        confidence: 0.3,
        page: 1,
      });
    }

    return res.json({ ok: true, fields });
  } catch (e) {
    return res.status(500).json({ ok: false, reasons: ['INTERNAL_ERROR'] });
  }
};
