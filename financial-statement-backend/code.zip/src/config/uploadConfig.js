export const MAX_PAGES = 6;
export const MAX_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB (adjust as you like)

export const ALLOWED_MIME = new Set([
  'application/pdf',
  'image/jpeg',
  'image/png',
]);

export const ALLOWED_EXT = new Set(['pdf', 'jpg', 'jpeg', 'png']);
