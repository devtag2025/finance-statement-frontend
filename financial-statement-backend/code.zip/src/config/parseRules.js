// Synonyms and simple regex anchors for common fields.
module.exports = {
  anchors: [
    { key: 'revenue.total',     labels: [/total\s+income/i, /gross\s+receipts/i, /revenue/i, /turnover/i] },
    { key: 'expenses.total',    labels: [/total\s+expenses?/i, /overall\s+expenses?/i, /operating\s+expenses?/i] },
    { key: 'profit.net',        labels: [/net\s+(income|profit|earnings)/i] },
    { key: 'profit.gross',      labels: [/gross\s+profit/i] },
    { key: 'deductions.total',  labels: [/total\s+deductions?/i, /allowable\s+deductions?/i] },
    { key: 'tax.payable',       labels: [/tax\s+payable/i, /tax\s+due/i] },
    { key: 'tax.refund',        labels: [/tax\s+refund/i] },
    { key: 'period.start',      labels: [/period\s+start/i, /from\s+date/i, /start\s+date/i] },
    { key: 'period.end',        labels: [/period\s+end/i, /to\s+date/i, /end\s+date/i] },
  ],

  // How many characters around a label to scan for a number
  window: 80,

  // Generic number near label
  numberPattern: /[-(]?\$?\s?\d{1,3}(?:[.,\s]\d{3})*(?:[.,]\d{2})?\)?/,

  // Date pattern (very simple; can enhance later)
  datePattern: /\b(\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4})\b/,
};
