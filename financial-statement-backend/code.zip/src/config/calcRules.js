// Minimal, safe, declarative rules. No eval.
// You can create multiple versions later and pick by ruleVersion.
module.exports = {
  defaultVersion: 'v1',
  versions: {
    v1: {
      // Sum of everything that looks like revenue.*
      'totals.revenue': { op: 'sumMatch', match: '^revenue\\.' },

      // Sum of everything that looks like expenses.*  (expenses are negative-friendly)
      'totals.expenses': { op: 'sumMatch', match: '^expenses?\\.' },

      // Gross profit if you also parse it independently (optional)
      // 'profit.gross': { op: 'sumMatch', match: '^profit\\.gross$' },

      // Net income = totals.revenue - totals.expenses
      net_income: {
        op: 'sub',
        a: { ref: 'totals.revenue' },
        b: { ref: 'totals.expenses' }
      },

      // Average monthly income (very naive: averages all revenue.* fields)
      avg_monthly_income: { op: 'avgMatch', match: '^revenue\\.' },

      // Allowed deductions example (min between fixed cap and sum of deductions.*)
      'deductions.allowed': {
        op: 'min',
        a: { const: 5000 },                   // configurable policy cap
        b: { op: 'sumMatch', match: '^deductions?\\.' }
      }
    }
  }
};
