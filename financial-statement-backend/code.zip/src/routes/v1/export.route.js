const express = require('express');
const { exportHandler } = require('../../controllers/export.controller');
const enforceEntitlements = require('../../middlewares/enforceEntitlements');
const requireAuth = require('../../middlewares/requireAuth');
const router = express.Router();

// NOTE: increase JSON limit if your payload is large
router.post('/export',
  requireAuth,
  enforceEntitlements({ requireActive: true }),
  express.json({ limit: '2mb' }),
  async (req, res) => {
    // ... your exportHandler code ...
    // On success, increment usage:
    res.on('finish', async () => {
      if (res.statusCode === 200 && req._writeUsage) {
        await req._writeUsage({ exports: 1 });
      }
    });
    return exportHandler(req, res);
  }
);

module.exports = router;
