const express = require('express');
const { parse } = require('../../controllers/parse.controller');

const router = express.Router();

// JSON body with { pages: [{ page: 1, text: "..." }, ...] }
router.post('/', express.json({ limit: '2mb' }), parse);

module.exports = router;
