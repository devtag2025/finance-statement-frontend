const express = require('express');
const { calc } = require('../../controllers/calc.controller');

const router = express.Router();

// JSON body: { fields: [{ id, label, value, included }], ruleVersion?: 'v1' }
router.post('/', express.json({ limit: '1mb' }), calc);

module.exports = router;
