const express = require('express');
const { createCheckout, createPortal } = require('../../controllers/billing.controller');
const requireAuth = require('../../middlewares/requireAuth');

const router = express.Router();

router.post('/create-checkout-session', requireAuth, express.json(), createCheckout);
router.post('/customer-portal', requireAuth, express.json(), createPortal);

module.exports = router;
