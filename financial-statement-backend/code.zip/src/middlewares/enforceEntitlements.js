const dayjs = require('dayjs');
const Users = require('../models/user.model');
const { stripe } = require('../services/payments.service');

// Optional: usage in Stripe metadata (DB-less)
async function readUsageFromStripe(user) {
  if (!user.stripeCustomerId) return { uploads: 0, exports: 0 };
  const customer = await stripe.customers.retrieve(user.stripeCustomerId);
  const md = customer.metadata || {};
  return {
    uploads: Number(md.uploads_count || 0),
    exports: Number(md.exports_count || 0),
    period: md.period || ''
  };
}

async function writeUsageToStripe(user, delta) {
  if (!user.stripeCustomerId) return;
  const customer = await stripe.customers.retrieve(user.stripeCustomerId);
  const md = customer.metadata || {};
  const exportsCount = Number(md.exports_count || 0) + (delta.exports || 0);
  const uploadsCount = Number(md.uploads_count || 0) + (delta.uploads || 0);
  await stripe.customers.update(user.stripeCustomerId, {
    metadata: {
      exports_count: String(exportsCount),
      uploads_count: String(uploadsCount),
      period: dayjs().format('YYYY-MM')
    }
  });
}

module.exports = function enforceEntitlements({ requireActive = true, limitPerMonth = { basic: 20, pro: 200 } } = {}) {
  return async function (req, res, next) {
    const user = req.user; // set by requireAuth
    if (!user) return res.status(401).json({ ok:false, reason:'UNAUTHENTICATED' });

    if (!requireActive) return next();

    // must have an active subscription
    if (!user.subscriptionStatus || !['active','trialing','past_due'].includes(user.subscriptionStatus)) {
      return res.status(402).json({ ok:false, reason:'SUBSCRIPTION_REQUIRED' });
    }

    // check monthly export limit
    try {
      const usage = await readUsageFromStripe(user);
      const planKey = user.planKey || 'basic';
      const cap = limitPerMonth[planKey] ?? 20;

      if ((usage.exports || 0) >= cap) {
        return res.status(402).json({ ok:false, reason:'LIMIT_REACHED', cap });
      }

      // mark intent; actual increment should happen ONLY after successful export
      req._usageMark = { planKey, cap, current: usage.exports || 0 };
      req._writeUsage = (delta) => writeUsageToStripe(user, delta);

      next();
    } catch (e) {
      return res.status(500).json({ ok:false, reason:'USAGE_CHECK_FAILED' });
    }
  };
};
