const { toNumber } = require('../utils/num');
const ruleConfig = require('../config/calcRules');

/**
 * Build a dictionary of numeric, included fields => { key: value }
 * key = normalized label like 'revenue.total' or 'expenses.rent'
 */
function buildFieldDict(fields = []) {
  const dict = {};
  const meta = {}; // map key -> [source field ids] (trace)

  for (const f of fields) {
    if (!f || f.included === false) continue;

    const key = String(f.label || '').trim().toLowerCase();
    if (!key) continue;

    const num = toNumber(f.value);
    if (num == null) continue;

    // If multiple rows share same label, aggregate as sum
    dict[key] = (dict[key] ?? 0) + num;
    if (!meta[key]) meta[key] = [];
    meta[key].push(f.id || key);
  }
  return { dict, meta };
}

function matchKeys(dict, pattern) {
  const re = new RegExp(pattern);
  return Object.keys(dict).filter(k => re.test(k));
}

function sumMatch(dict, meta, pattern) {
  const keys = matchKeys(dict, pattern);
  let sum = 0;
  const used = [];
  for (const k of keys) { sum += dict[k]; used.push(...(meta[k] || [])); }
  return { value: sum, used };
}

function avgMatch(dict, meta, pattern) {
  const keys = matchKeys(dict, pattern);
  if (!keys.length) return { value: 0, used: [] };
  let sum = 0;
  const used = [];
  for (const k of keys) { sum += dict[k]; used.push(...(meta[k] || [])); }
  return { value: sum / keys.length, used };
}

// Evaluate a node in our rule DSL safely (no eval)
function evalNode(node, env, trace) {
  if (!node) return { value: 0, used: [] };

  // Constant
  if (Object.prototype.hasOwnProperty.call(node, 'const')) {
    return { value: Number(node.const) || 0, used: [] };
  }

  // Reference to a computed key
  if (Object.prototype.hasOwnProperty.call(node, 'ref')) {
    const key = node.ref;
    return { value: env.results[key] ?? 0, used: trace[key] ?? [] };
  }

  // Operation
  switch (node.op) {
    case 'sumMatch': {
      const { value, used } = sumMatch(env.dict, env.meta, node.match);
      return { value, used };
    }
    case 'avgMatch': {
      const { value, used } = avgMatch(env.dict, env.meta, node.match);
      return { value, used };
    }
    case 'add': {
      const a = evalNode(node.a, env, trace);
      const b = evalNode(node.b, env, trace);
      return { value: a.value + b.value, used: [...a.used, ...b.used] };
    }
    case 'sub': {
      const a = evalNode(node.a, env, trace);
      const b = evalNode(node.b, env, trace);
      return { value: a.value - b.value, used: [...a.used, ...b.used] };
    }
    case 'mul': {
      const a = evalNode(node.a, env, trace);
      const b = evalNode(node.b, env, trace);
      return { value: a.value * b.value, used: [...a.used, ...b.used] };
    }
    case 'div': {
      const a = evalNode(node.a, env, trace);
      const b = evalNode(node.b, env, trace);
      return { value: b.value === 0 ? 0 : a.value / b.value, used: [...a.used, ...b.used] };
    }
    case 'min': {
      const a = evalNode(node.a, env, trace);
      const b = evalNode(node.b, env, trace);
      return a.value <= b.value ? a : b;
    }
    case 'max': {
      const a = evalNode(node.a, env, trace);
      const b = evalNode(node.b, env, trace);
      return a.value >= b.value ? a : b;
    }
    default:
      return { value: 0, used: [] };
  }
}

/**
 * Core engine
 * @param {Array} fields - parsed fields [{label, value, included, id}, ...]
 * @param {String} ruleVersion - 'v1' (default)
 */
function runCalc(fields, ruleVersion) {
  const version = ruleVersion || ruleConfig.defaultVersion;
  const rules = ruleConfig.versions[version];
  if (!rules) {
    return { ok: false, errors: ['UNKNOWN_RULE_VERSION'], results: {}, trace: {} };
  }

  const { dict, meta } = buildFieldDict(fields);
  const env = { dict, meta, results: {} };
  const trace = {}; // map outputKey -> array(fieldIds_used)

  // Evaluate in declaration order; later rules can reference earlier outputs via { ref: 'key' }
  for (const [outKey, node] of Object.entries(rules)) {
    const { value, used } = evalNode(node, env, trace);
    env.results[outKey] = Number.isFinite(value) ? Number(value) : 0;
    trace[outKey] = used;
  }

  return { ok: true, results: env.results, trace, errors: [] };
}

module.exports = { runCalc };
