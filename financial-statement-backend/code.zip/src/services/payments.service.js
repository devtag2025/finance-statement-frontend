const Stripe = require('stripe');
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2023-10-16' });

async function ensureCustomer(user) {
  if (user.stripeCustomerId) return user.stripeCustomerId;
  const customer = await stripe.customers.create({ email: user.email });
  user.stripeCustomerId = customer.id;
  await user.save();
  return customer.id;
}

async function createCheckoutSession({ user, planKey, successUrl, cancelUrl }) {
  const customerId = await ensureCustomer(user);
  const priceId = planKey === 'pro' ? process.env.STRIPE_PRICE_PRO : process.env.STRIPE_PRICE_BASIC;

  return await stripe.checkout.sessions.create({
    mode: 'subscription',
    customer: customerId,
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: `${successUrl}?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: cancelUrl,
    client_reference_id: String(user._id),
    allow_promotion_codes: true,
  });
}

async function createBillingPortal({ user, returnUrl }) {
  const customerId = await ensureCustomer(user);
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });
  return session;
}

async function getSubStatusFromStripe(stripeSubscriptionId) {
  if (!stripeSubscriptionId) return null;
  const sub = await stripe.subscriptions.retrieve(stripeSubscriptionId, { expand: ['items'] });
  return {
    status: sub.status,
    currentPeriodEnd: new Date(sub.current_period_end * 1000),
    priceId: sub.items.data[0]?.price?.id,
  };
}

module.exports = {
  stripe,
  ensureCustomer,
  createCheckoutSession,
  createBillingPortal,
  getSubStatusFromStripe,
};
