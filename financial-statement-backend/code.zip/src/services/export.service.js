const PDFDocument = require('pdfkit');
const { format } = require('@fast-csv/format');
const dayjs = require('dayjs');

/**
 * Streams a PDF into res. Does not write to disk.
 * @param {Response} res
 * @param {Object[]} fields - [{id,label,value,included,confidence,page}]
 * @param {Object} results - calc results object
 * @param {Object} opts - { title, brand, timezone }
 */
function streamPDF(res, fields, results, opts = {}) {
  const title = opts.title || 'Financial Statement Results';
  const tz = opts.timezone || 'UTC';
  const ts = dayjs().format('YYYY-MM-DD HH:mm');

  const doc = new PDFDocument({ size: 'A4', margin: 48 });
  // Pipe to response
  doc.pipe(res);

  // Header
  doc.fontSize(18).text(title, { align: 'left' });
  doc.moveDown(0.3);
  doc.fontSize(10).fillColor('#666')
     .text(`Generated: ${ts} (${tz})`, { align: 'left' });
  doc.moveDown(0.6);
  doc.fillColor('black');

  // Section: Summary Results
  doc.fontSize(14).text('Summary', { underline: true });
  doc.moveDown(0.4);
  doc.fontSize(11);
  const keys = Object.keys(results);
  if (!keys.length) {
    doc.text('No calculated results.');
  } else {
    keys.forEach((k) => {
      doc.text(`${k}: ${formatMoney(results[k])}`);
    });
  }

  doc.moveDown(0.8);

  // Section: Inputs (Included)
  doc.fontSize(14).text('Inputs (Included Fields)', { underline: true });
  doc.moveDown(0.4);
  doc.fontSize(10);

  const included = fields.filter(f => f && f.included);
  if (!included.length) {
    doc.text('No included fields.');
  } else {
    table(doc, ['Label', 'Value', 'Page', 'Confidence'], included.map(f => [
      f.label || '',
      safeString(f.value),
      String(f.page ?? ''),
      f.confidence != null ? `${Math.round(f.confidence * 100)}%` : ''
    ]));
  }

  // Section: Inputs (Excluded)
  doc.addPage();
  doc.fontSize(14).text('Inputs (Excluded Fields)', { underline: true });
  doc.moveDown(0.4);
  doc.fontSize(10);

  const excluded = fields.filter(f => f && !f.included);
  if (!excluded.length) {
    doc.text('No excluded fields.');
  } else {
    table(doc, ['Label', 'Value', 'Page', 'Confidence'], excluded.map(f => [
      f.label || '',
      safeString(f.value),
      String(f.page ?? ''),
      f.confidence != null ? `${Math.round(f.confidence * 100)}%` : ''
    ]));
  }

  // Footer
  doc.moveDown(1.2);
  doc.fontSize(9).fillColor('#666')
     .text('Note: Document processed transiently; no user data stored.', { align: 'left' });

  doc.end();
}

/**
 * Streams CSV into res. Flat schema: fields + results on separate sheets
 * For simplicity we output a single CSV containing both sections separated by a blank row.
 */
function streamCSV(res, fields, results) {
  const csv = format({ headers: true });

  // Section 1: Included fields
  csv.write({ SECTION: 'Included Fields' });
  csv.write({ Label: 'Label', Value: 'Value', Page: 'Page', Confidence: 'Confidence' });
  fields.filter(f => f && f.included).forEach(f => {
    csv.write({
      Label: f.label || '',
      Value: typeof f.value === 'number' ? f.value : String(f.value ?? ''),
      Page: f.page ?? '',
      Confidence: f.confidence != null ? Math.round(f.confidence * 100) + '%' : ''
    });
  });

  // Spacer
  csv.write({});
  csv.write({ SECTION: 'Excluded Fields' });
  csv.write({ Label: 'Label', Value: 'Value', Page: 'Page', Confidence: 'Confidence' });
  fields.filter(f => f && !f.included).forEach(f => {
    csv.write({
      Label: f.label || '',
      Value: typeof f.value === 'number' ? f.value : String(f.value ?? ''),
      Page: f.page ?? '',
      Confidence: f.confidence != null ? Math.round(f.confidence * 100) + '%' : ''
    });
  });

  // Spacer
  csv.write({});
  csv.write({ SECTION: 'Results' });
  csv.write({ Key: 'Metric', Value: 'Amount' });
  Object.entries(results || {}).forEach(([k, v]) => {
    csv.write({ Key: k, Value: v });
  });

  csv.pipe(res);
  csv.end();
}

// Helpers

function table(doc, headers, rows) {
  const startX = doc.x;
  let y = doc.y;

  // headers
  doc.font('Helvetica-Bold');
  headers.forEach((h, i) => {
    doc.text(String(h), startX + i * 150, y, { width: 140 });
  });
  y += 16;
  doc.font('Helvetica');

  rows.forEach(r => {
    r.forEach((cell, i) => {
      doc.text(String(cell), startX + i * 150, y, { width: 140 });
    });
    y += 14;
    if (y > doc.page.height - 72) { // simple page break
      doc.addPage(); 
      y = doc.y;
    }
  });

  doc.moveDown(1);
}

function safeString(v) {
  if (v == null) return '';
  if (typeof v === 'number') return formatMoney(v);
  return String(v);
}

function formatMoney(n) {
  if (typeof n !== 'number' || !Number.isFinite(n)) return String(n ?? '');
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(n);
}

module.exports = { streamPDF, streamCSV };
